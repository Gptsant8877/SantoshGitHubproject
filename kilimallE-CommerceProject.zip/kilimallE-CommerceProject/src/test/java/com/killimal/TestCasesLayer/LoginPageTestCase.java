package com.killimal.TestCasesLayer;

import org.testng.annotations.Test;

import com.killimal.Page.layer.BaseClass;
import com.killimal.Page.layer.HelthClass;
import com.killimal.Page.layer.HomePage;
import com.killimal.Page.layer.LoginPage;

public class LoginPageTestCase extends BaseClass {

	@Test
	public void verifyLoginPage() {

		LoginPage lg = new LoginPage(gm);
		lg.loginpage();

	}
	
//	@Test
//	public void verifyHomepage() {
//		HomePage hmp= new HomePage(gm);
//		hmp.kilimallHomePage();
//
//	}
//	
//	@Test
//	public void verifyHelthClass() {
//		HelthClass lsp = new HelthClass(gm);
//		lsp.helthClassMD();
//	}
//

}
