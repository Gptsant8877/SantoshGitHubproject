package com.killimal.TestCasesLayer;

import org.testng.annotations.Test;

import com.killimal.Page.layer.BaseClass;
import com.killimal.Page.layer.HelthClass;
import com.killimal.Page.layer.HomePage;
import com.killimal.Page.layer.LoginPage;

public class HelthClassTestCase extends BaseClass {
	

	

	@Test
	public void verifyHelthClass() {
		LoginPage lg = new LoginPage(gm);
		lg.loginpage();
		HomePage hmp= new HomePage(gm);
		hmp.kilimallHomePage();
		HelthClass lsp = new HelthClass(this.gm);
		lsp.helthClassMD();
		
		
	}

}
