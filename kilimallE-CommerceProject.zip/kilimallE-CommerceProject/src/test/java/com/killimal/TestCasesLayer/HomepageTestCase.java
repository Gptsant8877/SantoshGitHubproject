package com.killimal.TestCasesLayer;



import org.testng.annotations.Test;

import com.killimal.Page.layer.BaseClass;
import com.killimal.Page.layer.HomePage;
import com.killimal.Page.layer.LoginPage;

public class HomepageTestCase extends BaseClass{

 @Test
public void verifyHomepage() {
		LoginPage lg = new LoginPage(gm);
		lg.loginpage();
		HomePage hmp= new HomePage(gm);
		hmp.kilimallHomePage();
}


}
