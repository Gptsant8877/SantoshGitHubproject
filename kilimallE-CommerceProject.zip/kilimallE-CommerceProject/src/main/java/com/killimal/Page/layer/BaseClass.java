package com.killimal.Page.layer;

import java.lang.reflect.Method;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.killimal.WebUtill.layer.WebUtil;

public class BaseClass {

	protected WebUtil  gm=WebUtil.getInstance();
	@BeforeMethod
	public void setUp(Method method) {
		gm.createTestReport(method.getName());
		gm.launchbrowser("chrome");
		gm.openUrl("https://www.kilimall.co.ke/login");

	}  
	@AfterMethod
   public void closeSetUp() {
	   gm.driver.quit();
		gm.flushReport();
	}
	
	
	
}
