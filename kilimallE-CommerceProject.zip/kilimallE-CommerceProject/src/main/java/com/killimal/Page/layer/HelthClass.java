package com.killimal.Page.layer;

import com.killimal.PageOR.layer.HelthClassPageOR;
import com.killimal.WebUtill.layer.WebUtil;


public class HelthClass extends HelthClassPageOR {
	WebUtil gm=WebUtil.getInstance();
public HelthClass(WebUtil gm) {
	super(gm);
	this.gm=gm;
}



public void helthClassMD() {
	//gm.click(getladieshoesLK(), "click on ladies shoes centre");
	gm.mouseOver(getPopularLKLK());
	gm.mouseOver(getTopsaleLK());
	gm.mouseOver(getLatestLK());
	gm.mouseOver(getPriceLK());
	
	gm.actionDoubleClick(getHighAndHighLK());
//	gm.mouseOver(getShippedFromLK());
//	gm.mouseOver(getOverseaShipmentLK());
//	gm.mouseOver(getBrandLK());
//	gm.mouseOver(getGenericLK());
}
}
