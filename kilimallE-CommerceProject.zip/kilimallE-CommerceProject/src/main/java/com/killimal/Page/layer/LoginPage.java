package com.killimal.Page.layer;

import com.killimal.PageOR.layer.LoginPageOR;
import com.killimal.WebUtill.layer.WebUtil;

public class LoginPage extends LoginPageOR{

	WebUtil gm=WebUtil.getInstance();
	public LoginPage(WebUtil gm) {
		super(gm);
		this.gm=gm;
	}

	public void loginpage() {

		//gm.launchbrowser("chrome");
		//gm.openUrl("https://www.kilimall.co.ke/login");
	//	gm.mouseOver(getImgLOGO());
		try {
			Thread.sleep(6000);
			gm.inputValue(getUserNameTBX(), "gptsant@gmail.com");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		gm.inputValue(getUserPasswordTBX(), "Sant8877@");
		gm.mouseOver(getForgotPasswordLK());
		gm.mouseOver(getLoginwithsmsLK());
		gm.mouseOver(getLoginViaGoogleLK());
		gm.mouseOver(getLoginViaFBLK());
		gm.mouseOver(getRegisterLK());
		gm.click(getLoginBT(), "click on Login Button");
	}
	}

