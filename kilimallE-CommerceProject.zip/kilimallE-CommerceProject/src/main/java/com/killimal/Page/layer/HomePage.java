package com.killimal.Page.layer;


import com.killimal.PageOR.layer.HomePageOr;
import com.killimal.WebUtill.layer.WebUtil;


public class HomePage extends HomePageOr {
	WebUtil gm=WebUtil.getInstance();

public HomePage(WebUtil gm) {
	super(gm);
	this.gm=gm;
} 

	public void kilimallHomePage() {
		//gm.inputValue(SearchBX, "Shoes");
		//gm.click(SearchBT, "click on Button");
		gm.click(getWrapperTB(),"click on rapper tab");
		gm.mouseOver(getNewKiliFeacherLK());
		gm.mouseOver(getTVAVideoLK());
		gm.mouseOver(getPhoneLK());
		gm.mouseOver(getHomeLK());
		gm.click(getHelthLK(),"click on helth link");
		//gm.click(getKidsBabyLK(), "click on kids and babby link");
		
//		
//		gm.mouseOver(getLadiesLK());
//		gm.mouseOver(getTVLK());
//		gm.mouseOver(getMenTShirtLK());
//		gm.mouseOver(getSamsunglLK());
//		gm.mouseOver(getBagslLK());
//		gm.mouseOver(getDuvetlLK());
//		gm.mouseOver(getMenWatchLK());
//		gm.mouseOver(getHeaterLK());
//		//gm.mouseOver(getKilliFeacherLK());
//		
//		gm.mouseOver(getShoesLK());
//		
//		
//		
//		gm.mouseOver(getAppliancesLK());
//		gm.mouseOver(getBagsLK());
//		gm.mouseOver(getClothesLK());
//		gm.mouseOver(getWatchJewLK());
//		gm.mouseOver(getComputerLK());
//		gm.mouseOver(getKiddsLK());
//		gm.mouseOver(getAutomotiveLK());
//		gm.mouseOver(getOthersLK());
//		gm.click(getLadiesLK(), "click on ladies shoues button");

	}

}



