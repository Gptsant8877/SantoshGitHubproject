package com.killimal.PageOR.layer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.killimal.WebUtill.layer.WebUtil;

public class HelthClassPageOR {
	WebUtil gm=WebUtil.getInstance();
public HelthClassPageOR(WebUtil gm) {
	this.gm=gm;
	PageFactory.initElements(gm.driver, this);
}


	@FindBy(xpath = "//span[contains(text(),'Popular')]")
	WebElement PopularLK;

	@FindBy(xpath = "//span[contains(text(),'Top Sale')]")
	WebElement TopsaleLK;

	@FindBy(xpath = "//span[contains(text(),'Latest')]")
	WebElement LatestLK;

	@FindBy(xpath = "//span[contains(text(),'Price')]")
	WebElement PriceLK;
	
	

	@FindBy(xpath = "//p[contains(text(),'High to Low')]")
	WebElement HighLowLK;
//
//	@FindBy(xpath = "//div[contains(text(),'Knee-High')]")
//	WebElement KneeHighLK;
//
//	@FindBy(xpath = "//div[contains(text(),'Shipped From')]")
//	WebElement ShippedFromLK;
//
//	@FindBy(xpath = "//div[contains(text(),'Oversea Shipment')]")
//	WebElement OverseaShipmentLK;
//
//	@FindBy(xpath = "//div[contains(text(),'Brand')]")
//	WebElement BrandLK;
//
//	@FindBy(xpath = "//div[contains(text(),'Generic')]")
//	WebElement GenericLK;

	public WebElement getPopularLKLK() {
		return PopularLK;
	}
	public WebElement getTopsaleLK() {
		return TopsaleLK;
	}
	public WebElement getLatestLK() {
		return LatestLK;
	}
	public WebElement getPriceLK() {
		return PriceLK;
	}
	public WebElement getHighAndHighLK() {
		return HighLowLK;
	}
//	public WebElement getKneeHighLK() {
//		return KneeHighLK;
//	}
//	public WebElement getShippedFromLK() {
//		return ShippedFromLK;
//	}
//	public WebElement getOverseaShipmentLK() {
//		return OverseaShipmentLK;
//	}
//	public WebElement getBrandLK() {
//		return BrandLK;
//	}
//	public WebElement getGenericLK() {
//		return GenericLK;
	}
