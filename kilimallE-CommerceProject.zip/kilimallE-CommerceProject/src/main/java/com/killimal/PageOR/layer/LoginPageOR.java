package com.killimal.PageOR.layer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.killimal.WebUtill.layer.WebUtil;

public class LoginPageOR {
	WebUtil gm=WebUtil.getInstance();
	public LoginPageOR(WebUtil gm) {
		this.gm=gm;
		PageFactory.initElements(gm.driver, this);
	}
	@FindBy(xpath = "//img[@class='logo-img']")
	WebElement ImgLOGO;

	@FindBy(xpath = "//input[@placeholder='Phone No./email']")
	WebElement UserNameTBX;

	@FindBy(xpath = "//input[@placeholder='Please input password']")
	WebElement UserPasswordTBX;

	@FindBy(xpath = "//span[contains(text(),'forgot password')]")
	WebElement ForgotPasswordLK;

	@FindBy(xpath = "//span[contains(text(),'login in with SMS')]")
	WebElement LoginwithsmsLK;

	@FindBy(xpath = "//div[contains(text(),' Login Via Google ')]")
	WebElement LoginViaGoogleLK;

	@FindBy(xpath = "//div[contains(text(),' Login Via Facebook ')]")
	WebElement LoginViaFBLK;

	@FindBy(xpath = "//span[contains(text(),'Register')]")
	WebElement RegisterLK;

	@FindBy(xpath = "//input[@type='password']//parent::div//parent::div[@class='van-cell__value van-field__value']//parent::div//following-sibling::div//button[@type='submit']")
	WebElement LoginBT;

	public WebElement getImgLOGO() {
		return ImgLOGO;
	}
	public WebElement getUserNameTBX() {
		return UserNameTBX;
	}
	public WebElement getUserPasswordTBX() {
		return UserPasswordTBX;
	}
	public WebElement getForgotPasswordLK() {
		return ForgotPasswordLK;
	}
	public WebElement getLoginwithsmsLK() {
		return LoginwithsmsLK;
	}
	public WebElement getLoginViaGoogleLK() {
		return LoginViaGoogleLK;
	}
	public WebElement getLoginViaFBLK() {
		return LoginViaFBLK;
	}
	public WebElement getRegisterLK() {
		return RegisterLK;
	}


	public WebElement getLoginBT() {
		return LoginBT;
	}
	}


