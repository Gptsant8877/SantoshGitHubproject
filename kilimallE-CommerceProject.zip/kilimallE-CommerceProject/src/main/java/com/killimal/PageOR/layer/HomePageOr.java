package com.killimal.PageOR.layer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.killimal.WebUtill.layer.WebUtil;

public class HomePageOr {
	WebUtil gm=WebUtil.getInstance();
public HomePageOr(WebUtil gm) {
	this.gm=gm;
	PageFactory.initElements(gm.driver, this);


}
@FindBy(xpath = "//input[@id='van-field-22335-input']")
private WebElement  SearchBX;

@FindBy(xpath = "//div[@class='search-button']")
private WebElement  SearchBT;

@FindBy(xpath = "//p[contains(text(),'Kili Featured')]")
private WebElement  NewKiliFeacherLK;

@FindBy(xpath = "//i[@class='van-badge__wrapper van-icon van-icon-bars']")
private WebElement WrapperTB;

@FindBy(xpath = "//a[contains(text(),'ladies shoes')]")
private WebElement  LadiesLK;

@FindBy(xpath = "//p[contains(text(),'TV,Audio&Video')]")
private WebElement  TVLK;

@FindBy(xpath = "//a[contains(text(),'men t-shirt')]")
private WebElement  MenTShirtLK;

@FindBy(xpath = "//a[contains(text(),'samsung')]")
private WebElement  SamsunglLK;

@FindBy(xpath = "//a[contains(text(),'bags')]")
private WebElement  BagslLK;

@FindBy(xpath = "//a[contains(text(),'duvet')]")
private WebElement  DuvetlLK;

@FindBy(xpath = "//a[contains(text(),'men watches')]")
private WebElement  MenWatchLK;

@FindBy(xpath = "//a[contains(text(),'Heater')]")
private WebElement  HeaterLK;

@FindBy(xpath = "//p[contains(text(),'Kili Featured')]")
private WebElement  KilliFeacherLK;


@FindBy(xpath = "//p[contains(text(),'TV,Audio&Video')]")
private WebElement  TVAVideoLK;

@FindBy(xpath = "//p[contains(text(),'Shoes')]")
private WebElement  ShoesLK;

@FindBy(xpath = "//p[contains(text(),'Phones & Accessories')]")
private WebElement  PhoneLK;

@FindBy(xpath = "//p[contains(text(),'Home & Kitchen')]")
private WebElement  HomeLK;

@FindBy(xpath = "//p[contains(text(),'Health & Beauty')]")
private WebElement  HelthLK;

@FindBy(xpath = "//p[contains(text(),'Appliances')]")
private WebElement  AppliancesLK;

@FindBy(xpath = "//p[contains(text(),'Bags')]")
private WebElement  BagsLK;

@FindBy(xpath = "//p[contains(text(),'Clothes')]")
private WebElement  ClothesLK;

@FindBy(xpath = "//p[contains(text(),'Watches & Jewellery')]")
private WebElement  WatchJewLK;

@FindBy(xpath = "//p[contains(text(),'Computers & Accessories')]")
private WebElement  ComputerLK;

@FindBy(xpath = "//p[contains(text(),'Kids & Baby Products')]")
private WebElement  KiddsLK;

@FindBy(xpath = "//p[contains(text(),'Automotive')]")
private WebElement  AutomotiveLK;

@FindBy(xpath = "//p[contains(text(),'Others')]")
private WebElement  OthersLK;

@FindBy(xpath = "//p[contains(text(),'Kids & Baby Products')]")
private WebElement KidsBabyLK;

public WebElement getKidsBabyLK() {
	return KidsBabyLK;
}

public WebElement getSearchBX() {
	return SearchBX;
}


public WebElement getSearchBT() {
return SearchBT;
}
public WebElement getNewKiliFeacherLK() {
return NewKiliFeacherLK;
}
public WebElement getLadiesLK() {
return LadiesLK;
}

public WebElement getTVLK() {
return TVLK;
}
public WebElement getMenTShirtLK() {
return MenTShirtLK;
}
public WebElement getSamsunglLK() {
return SamsunglLK;
}
public WebElement getBagslLK() {
return BagslLK;
}
public WebElement getDuvetlLK() {
return DuvetlLK;
}
public WebElement getMenWatchLK() {
return MenWatchLK;
}
public WebElement getHeaterLK() {
return HeaterLK;
}


public WebElement getTVAVideoLK() {
return TVAVideoLK;
}
public WebElement getShoesLK() {
return ShoesLK;
}
public WebElement getPhoneLK() {
return PhoneLK;
}
public WebElement getHomeLK() {
return HomeLK;
}
public WebElement getHelthLK() {
return HelthLK;
}
public WebElement getAppliancesLK() {
return AppliancesLK;
}
public WebElement getBagsLK() {
return BagsLK;
}
public WebElement getClothesLK() {
return ClothesLK;
}
public WebElement getWatchJewLK() {
return WatchJewLK;
}
public WebElement getComputerLK() {
return ComputerLK;
}
public WebElement getKiddsLK() {
return KiddsLK;
}
public WebElement getAutomotiveLK() {
return AutomotiveLK;
}
public WebElement getOthersLK() {
return OthersLK;
}

public WebElement getWrapperTB() {
	return WrapperTB;
}
}
